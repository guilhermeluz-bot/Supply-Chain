const today=new Date();today.setHours(0,0,0,0);
let lots=[
 {name:"Cacau em pó",code:"#CA204",qty:"4,5 kg",date:addDays(2)},
 {name:"Leite integral",code:"#LT118",qty:"12 un.",date:addDays(5)},
 {name:"Chocolate",code:"#CH092",qty:"3 kg",date:addDays(7)},
 {name:"Café em grãos",code:"#CF071",qty:"8 kg",date:addDays(18)},
 {name:"Farinha de trigo",code:"#FT044",qty:"15 kg",date:addDays(35)},
 {name:"Açúcar mascavo",code:"#AC030",qty:"6 kg",date:addDays(-2)}
];
let movements=[
 ["03/11/2026","Cacau em pó • #CA204","Venda","500 g","Equipe"],
 ["03/11/2026","Leite integral • #LT118","Entrada","12 un.","Equipe"],
 ["02/11/2026","Chocolate • #CH092","Baixa por degustação","200 g","Equipe"],
 ["01/11/2026","Farinha de trigo • #FT044","Destinação social","2 kg","Equipe"]
];
function addDays(n){let d=new Date(today);d.setDate(d.getDate()+n);return d}
function daysLeft(d){return Math.ceil((new Date(d)-today)/86400000)}
function fmt(d){return new Date(d).toLocaleDateString("pt-BR")}
function status(d){let n=daysLeft(d);return n<0?["Vencido","bad"]:n<=7?["Atenção","warn"]:["Em dia","ok"]}
function showPage(id){document.querySelectorAll(".page").forEach(p=>p.classList.toggle("active",p.id===id));document.querySelectorAll(".nav button").forEach(b=>b.classList.toggle("active",b.dataset.page===id));document.getElementById("pageTitle").textContent=({dashboard:"Visão geral",estoque:"Estoque e lotes",movimentacoes:"Movimentações",relatorios:"Relatórios"})[id];if(id==="estoque")renderTable();if(id==="movimentacoes")renderMoves();window.scrollTo({top:0,behavior:"smooth"})}
document.querySelectorAll(".nav button").forEach(b=>b.addEventListener("click",()=>showPage(b.dataset.page)));
function renderRows(target,arr){document.getElementById(target).innerHTML=arr.map(l=>{let s=status(l.date);return `<tr><td><b>${escapeHtml(l.name)}</b></td><td>${escapeHtml(l.code)}</td><td>${escapeHtml(l.qty)}</td><td>${fmt(l.date)}</td><td><span class="pill ${s[1]}">${s[0]}</span></td></tr>`}).join("")||'<tr><td colspan="5" class="empty">Nenhum lote encontrado.</td></tr>'}
function renderTable(){let q=(document.getElementById("searchProduct")?.value||"").toLowerCase(),f=document.getElementById("statusFilter")?.value||"todos";let filtered=lots.filter(l=>(l.name+" "+l.code).toLowerCase().includes(q)&&(f==="todos"||status(l.date)[1]===f));renderRows("stockRows",filtered)}
function renderUrgent(){renderRows("urgentRows",lots.filter(l=>daysLeft(l.date)<=7).sort((a,b)=>a.date-b.date))}
function renderMoves(){document.getElementById("moveRows").innerHTML=movements.map(m=>`<tr>${m.map(x=>`<td>${escapeHtml(x)}</td>`).join("")}</tr>`).join("")}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function toast(msg){let t=document.getElementById("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2600)}
document.getElementById("addForm").addEventListener("submit",e=>{e.preventDefault();let date=new Date(document.getElementById("expiry").value+"T00:00:00");lots.push({name:document.getElementById("prodName").value,code:document.getElementById("lotCode").value,qty:document.getElementById("qty").value,date});renderTable();renderUrgent();document.getElementById("totalLots").textContent=46+lots.length-6;document.getElementById("nearCount").textContent=String(lots.filter(l=>daysLeft(l.date)<=7&&daysLeft(l.date)>=0).length).padStart(2,"0");e.target.reset();toast("Lote adicionado ao protótipo!")});
document.getElementById("movementForm").addEventListener("submit",e=>{e.preventDefault();let select=document.getElementById("moveProduct"),lot=lots[Number(select.value)];if(!lot){toast("Cadastre um lote primeiro.");return}movements.unshift([new Date().toLocaleDateString("pt-BR"),lot.name+" • "+lot.code,document.getElementById("moveType").value,document.getElementById("moveQty").value,document.getElementById("moveOwner").value||"Não informado"]);renderMoves();e.target.reset();toast("Movimentação registrada!")});
function fillMoveSelect(){document.getElementById("moveProduct").innerHTML=lots.map((l,i)=>`<option value="${i}">${escapeHtml(l.name)} • ${escapeHtml(l.code)}</option>`).join("")}
renderUrgent();renderTable();renderMoves();fillMoveSelect();
