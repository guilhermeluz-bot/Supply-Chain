SUPPLY CHAIN — Protótipo de gestão de estoque

ESTRUTURA:
- index.html: estrutura das páginas
- css/style.css: estilos e layout
- js/script.js: interações, dados demonstrativos e funcionalidades

COMO ABRIR:
1. Extraia a pasta SUPPLY-CHAIN.
2. Abra o Visual Studio Code.
3. Clique em Arquivo > Abrir Pasta.
4. Selecione a pasta SUPPLY-CHAIN.
5. Abra o index.html e execute com Live Server (se tiver instalado),
   ou abra o index.html diretamente no navegador.

OBSERVAÇÃO:
Este é um protótipo front-end. Os dados são demonstrativos e não ficam
salvos permanentemente; ainda não há banco de dados conectado.
